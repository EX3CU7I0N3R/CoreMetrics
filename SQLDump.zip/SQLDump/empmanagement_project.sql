CREATE DATABASE  IF NOT EXISTS `empmanagement` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `empmanagement`;
-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: empmanagement
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS `project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project` (
  `ProjectID` int NOT NULL,
  `EmployeeID` int DEFAULT NULL,
  `ProjectInfo` varchar(255) DEFAULT NULL,
  `SuccessIndicator` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ProjectID`),
  KEY `EmployeeID` (`EmployeeID`),
  CONSTRAINT `project_ibfk_1` FOREIGN KEY (`EmployeeID`) REFERENCES `employee` (`EmpID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project`
--

LOCK TABLES `project` WRITE;
/*!40000 ALTER TABLE `project` DISABLE KEYS */;
INSERT INTO `project` VALUES (100,123,'Predictive Maintenance for Industrial Equipment','Under review'),(101,180,'Telehealth Platform for Mental Health','Within budget'),(102,176,'AR Experience in Historical Sites','Over budget'),(103,121,'Voice-Activated Reading Assistant','In progress'),(104,120,'Digital Marketplace for Freelancers','Delayed'),(105,164,'Augmented Reality Shopping Experience','On hold'),(106,134,'Professional Networking App for Creatives','Cancelled'),(107,177,'App for Local Community Events','Within budget'),(108,106,'Home Renovation Virtual Reality Tours','Not started'),(109,184,'Platform for Virtual Hackathons','Over budget'),(110,100,'Real-Time Language Translation Earbuds','Cancelled'),(111,166,'Online Marketplace for Local Artisans','Exceeded expectations'),(112,161,'IoT Solutions for Smart Cities','Within budget'),(113,159,'Augmented Reality Learning for STEM','Not started'),(114,155,'Multilingual Translation Software for Businesses','Exceeded expectations'),(115,168,'Professional Networking App for Creatives','Exceeded expectations'),(116,138,'Blockchain for Fair Trade Certification','Not started'),(117,132,'Automated Tax Preparation Software','Exceeded expectations'),(118,128,'AI-Based Talent Recruitment Platform','Within budget'),(119,175,'Interactive Fitness Games using AR','Over budget'),(120,135,'On-Demand Repair Services via Mobile App','Within budget'),(121,186,'Cloud-Based Document Collaboration Tool','Exceeded expectations'),(122,188,'AI-Enhanced Music Recommendation Service','Delayed'),(123,178,'Mobile Wallet for Cryptocurrency Transactions','Exceeded expectations'),(124,108,'Blockchain for Supply Chain Transparency','Not started'),(125,156,'Regenerative Farming Technology','On hold'),(126,143,'Digital Tools for Remote Workers','In progress'),(127,137,'Data Privacy Compliance Toolkit','Cancelled'),(128,141,'Data Visualization Tools for Business Intelligence','Under review'),(129,179,'Elderly Care Monitoring System','Under review'),(130,111,'Virtual Influencer Marketing Agency','In progress'),(131,187,'Sustainable Energy Management System','On hold'),(132,117,'Remote Monitoring of Patient Health Data','Within budget'),(133,124,'Smart Mirror with Virtual Stylist','Over budget'),(134,199,'Television Streaming Service for Niche Audiences','Completed on time'),(135,130,'Decentralized Social Media Platform','Under review'),(136,196,'Remote Monitoring of Patient Health Data','In progress'),(137,115,'Automated Translation Services for Meetings','Not started'),(138,148,'Automated Translation Services for Meetings','Delayed'),(139,149,'Augmented Reality Shopping Experience','Under review'),(140,157,'AI-Driven Content Recommendation Engine','Cancelled'),(141,116,'Regenerative Farming Technology','Over budget'),(142,147,'Cloud Solutions for Nonprofits','Under review'),(143,181,'Cloud Storage Solutions for Small Businesses','Cancelled'),(144,173,'Blockchain Solutions for Transparent Charities','Under review'),(145,172,'Smart Waste Management Solution','Delayed'),(146,112,'AI-Based Video Content Creation Platform','In progress'),(147,198,'Blockchain for Fair Trade Certification','Over budget'),(148,125,'Cloud Solutions for Nonprofits','Within budget'),(149,169,'Telemedicine Platform for Rural Areas','Under review'),(150,102,'Quantum Computing Simulation Software','Over budget'),(151,136,'Cloud Gaming Service','In progress'),(152,142,'Regenerative Farming Technology','Over budget'),(153,126,'Smart Parking Solutions','Under review'),(154,107,'Drone-Based Delivery System','Exceeded expectations'),(155,101,'Personalized Reading App using Machine Learning','On hold'),(156,174,'Online Learning for Career Development','On hold'),(157,170,'Next-Gen Online Tutoring Platform','Over budget'),(158,182,'Personalized Travel Planning App','On hold'),(159,163,'Green Energy Solutions for Homeowners','Under review'),(160,193,'Quantum Computing Simulation Software','Within budget'),(161,104,'Interactive Online Learning Experiences','Over budget'),(162,139,'Comprehensive HR Management Solution','Over budget'),(163,153,'AI For Predicting Stock Market Trends','Delayed'),(164,131,'Blockchain for Supply Chain Transparency','Exceeded expectations'),(165,145,'App for Local Community Events','On hold'),(166,140,'Telehealth Platform for Mental Health','Completed on time'),(167,114,'Online Reputation Management Platform','Under review'),(168,129,'AI-Powered Photo Editing Tool','Completed on time'),(169,183,'Online Platform for Sustainable Products','Delayed'),(170,118,'Regenerative Farming Technology','Within budget'),(171,109,'Remote Monitoring of Patient Health Data','Under review'),(172,154,'Natural Language Processing for Customer Support','Cancelled'),(173,151,'Social Impact Investing Platform','Over budget'),(174,144,'Crowdsourced Environmental Monitoring Platform','Not started'),(175,171,'Cloud-Based Document Collaboration Tool','Under review'),(176,160,'Mobile Payment Solution for Small Businesses','Cancelled'),(177,150,'Personalized Travel Planning App','Not started'),(178,167,'Professional Networking App for Creatives','Not started'),(179,127,'Home Renovation Virtual Reality Tours','Cancelled'),(180,146,'App for Local Community Events','In progress'),(181,152,'Automated Translation Services for Meetings','Cancelled'),(182,185,'AI-Based Talent Recruitment Platform','Delayed'),(183,105,'Next-Gen Online Tutoring Platform','Not started'),(184,158,'Cloud Storage Solutions for Small Businesses','On hold'),(185,103,'AI-Powered Personal Finance Assistant','Exceeded expectations'),(186,165,'Smart Gloves for Remote Work','In progress'),(187,119,'Personalized Fitness Coaching App','Delayed'),(188,195,'Multilingual Translation Software for Businesses','Completed on time'),(189,197,'Online Marketplace for Local Artisans','Delayed'),(190,110,'Remote Work Virtual Reality Office','Cancelled'),(191,133,'Cloud Storage Solutions for Small Businesses','In progress'),(192,122,'Smart Inventory Management System','Delayed'),(193,113,'Automated Translation Services for Meetings','Within budget'),(194,162,'Automated Tax Preparation Software','Within budget'),(195,192,'Voice-Activated Reading Assistant','Over budget'),(196,189,'Digital Marketplace for Freelancers','Exceeded expectations'),(197,191,'App for Local Community Events','Under review'),(198,190,'Smart Gym Equipment with AI Coaching','In progress'),(199,194,'Smart Weather Monitoring Station','Over budget');
/*!40000 ALTER TABLE `project` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-17 23:20:34
